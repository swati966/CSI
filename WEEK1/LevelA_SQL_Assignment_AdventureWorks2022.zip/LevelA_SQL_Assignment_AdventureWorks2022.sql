
USE AdventureWorks2022;
GO

-- 1. List of all customers
SELECT * FROM Sales.Customer;
GO

-- 2. List of all customers where company name ending in N
SELECT c.CustomerID, s.Name AS CompanyName
FROM Sales.Customer c
JOIN Sales.Store s ON c.StoreID = s.BusinessEntityID
WHERE s.Name LIKE '%N';
GO

-- 3. List of all customers who live in Berlin or London
SELECT DISTINCT c.CustomerID, a.City
FROM Sales.Customer c
JOIN Person.BusinessEntityAddress bea ON bea.BusinessEntityID = c.PersonID
JOIN Person.Address a ON bea.AddressID = a.AddressID
WHERE a.City IN ('Berlin', 'London');
GO

-- 4. List of all customers who live in UK or USA
SELECT DISTINCT c.CustomerID, sp.CountryRegionCode AS Country
FROM Sales.Customer c
JOIN Person.BusinessEntityAddress bea ON bea.BusinessEntityID = c.PersonID
JOIN Person.Address a ON bea.AddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
WHERE sp.CountryRegionCode IN ('GB', 'US');
GO

-- 5. List of all products sorted by product name
SELECT * FROM Production.Product ORDER BY Name ASC;
GO

-- 6. List of all products where product name starts with an A
SELECT * FROM Production.Product WHERE Name LIKE 'A%';
GO

-- 7. List of customers who ever placed an order
SELECT DISTINCT c.CustomerID
FROM Sales.SalesOrderHeader o
JOIN Sales.Customer c ON o.CustomerID = c.CustomerID;
GO

-- 8. List of Customers who live in London and have bought Chai
SELECT DISTINCT c.CustomerID
FROM Sales.SalesOrderHeader o
JOIN Sales.SalesOrderDetail od ON o.SalesOrderID = od.SalesOrderID
JOIN Production.Product p ON od.ProductID = p.ProductID
JOIN Sales.Customer c ON o.CustomerID = c.CustomerID
JOIN Person.BusinessEntityAddress bea ON bea.BusinessEntityID = c.PersonID
JOIN Person.Address a ON bea.AddressID = a.AddressID
WHERE a.City = 'London' AND p.Name = 'Chai';
GO

-- 9. List of customers who never placed an order
SELECT c.CustomerID
FROM Sales.Customer c
WHERE c.CustomerID NOT IN (SELECT DISTINCT CustomerID FROM Sales.SalesOrderHeader);
GO

-- 10. List of customers who ordered Tofu
SELECT DISTINCT c.CustomerID
FROM Sales.SalesOrderHeader o
JOIN Sales.SalesOrderDetail od ON o.SalesOrderID = od.SalesOrderID
JOIN Production.Product p ON od.ProductID = p.ProductID
JOIN Sales.Customer c ON o.CustomerID = c.CustomerID
WHERE p.Name = 'Tofu';
GO

-- 11. Details of first order of the system
SELECT TOP 1 * FROM Sales.SalesOrderHeader ORDER BY OrderDate ASC;
GO

-- 12. Most expensive order date
SELECT TOP 1 OrderDate, TotalDue FROM Sales.SalesOrderHeader ORDER BY TotalDue DESC;
GO

-- 13. For each order get orderID and average quantity of items
SELECT SalesOrderID, AVG(OrderQty) AS AvgQty
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID;
GO

-- 14. For each order get orderID, min qty and max qty
SELECT SalesOrderID, MIN(OrderQty) AS MinQty, MAX(OrderQty) AS MaxQty
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID;
GO

-- 15. Managers and number of employees reporting to them using OrganizationNode hierarchy
SELECT e2.OrganizationNode.ToString() AS ManagerNode, COUNT(*) AS NumEmployees
FROM HumanResources.Employee e1
JOIN HumanResources.Employee e2 ON e1.OrganizationNode.GetAncestor(1) = e2.OrganizationNode
GROUP BY e2.OrganizationNode.ToString()
ORDER BY NumEmployees DESC;
GO

-- (Rest of the queries continue — for brevity here in code execution I'll include up to Q15)


-- 16. Orders with total quantity > 300
SELECT SalesOrderID, SUM(OrderQty) AS TotalQty
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
HAVING SUM(OrderQty) > 300;
GO

-- 17. Orders placed on or after 1996/12/31
SELECT * FROM Sales.SalesOrderHeader WHERE OrderDate >= '1996-12-31';
GO

-- 18. Orders shipped to Canada
SELECT * FROM Sales.SalesOrderHeader
WHERE ShipToAddressID IN (
    SELECT AddressID FROM Person.Address
    WHERE StateProvinceID IN (
        SELECT StateProvinceID FROM Person.StateProvince
        WHERE CountryRegionCode = 'CA'
    )
);
GO

-- 19. Orders with total > 200
SELECT * FROM Sales.SalesOrderHeader WHERE TotalDue > 200;
GO

-- 20. Countries and sales made in each country
SELECT sp.CountryRegionCode, SUM(soh.TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader soh
JOIN Person.Address a ON soh.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
GROUP BY sp.CountryRegionCode;
GO

-- 21. CustomerID and number of orders placed
SELECT c.CustomerID, COUNT(o.SalesOrderID) AS NumOrders
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID;
GO

-- 22. Customers with more than 3 orders
SELECT c.CustomerID, COUNT(o.SalesOrderID) AS NumOrders
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
HAVING COUNT(o.SalesOrderID) > 3;
GO

-- 23. Discontinued products ordered between 1/1/1997 and 1/1/1998
SELECT DISTINCT p.ProductID, p.Name
FROM Production.Product p
JOIN Sales.SalesOrderDetail od ON p.ProductID = od.ProductID
JOIN Sales.SalesOrderHeader o ON od.SalesOrderID = o.SalesOrderID
WHERE p.SellEndDate IS NOT NULL
AND o.OrderDate BETWEEN '1997-01-01' AND '1998-01-01';
GO

-- 24. Employee and their manager name
SELECT e.BusinessEntityID, p.FirstName, p.LastName,
    m.FirstName AS ManagerFirstName, m.LastName AS ManagerLastName
FROM HumanResources.Employee e
JOIN Person.Person p ON e.BusinessEntityID = p.BusinessEntityID
LEFT JOIN HumanResources.Employee em ON e.OrganizationNode.GetAncestor(1) = em.OrganizationNode
LEFT JOIN Person.Person m ON em.BusinessEntityID = m.BusinessEntityID;
GO

-- 25. EmployeeID and total sales by employee
SELECT SalesPersonID, SUM(TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader
WHERE SalesPersonID IS NOT NULL
GROUP BY SalesPersonID;
GO

-- 26. Employees whose first name contains 'a'
SELECT e.BusinessEntityID, p.FirstName, p.LastName
FROM HumanResources.Employee e
JOIN Person.Person p ON e.BusinessEntityID = p.BusinessEntityID
WHERE p.FirstName LIKE '%a%';
GO

-- 27. Managers with more than 4 people reporting to them
SELECT e2.OrganizationNode.ToString() AS ManagerNode, COUNT(*) AS NumReports
FROM HumanResources.Employee e1
JOIN HumanResources.Employee e2 ON e1.OrganizationNode.GetAncestor(1) = e2.OrganizationNode
GROUP BY e2.OrganizationNode.ToString()
HAVING COUNT(*) > 4;
GO

-- 28. Orders and product names
SELECT o.SalesOrderID, p.Name
FROM Sales.SalesOrderDetail od
JOIN Sales.SalesOrderHeader o ON od.SalesOrderID = o.SalesOrderID
JOIN Production.Product p ON od.ProductID = p.ProductID;
GO

-- 29. Orders placed by the best customer
SELECT TOP 1 o.CustomerID, COUNT(o.SalesOrderID) AS NumOrders
FROM Sales.SalesOrderHeader o
GROUP BY o.CustomerID
ORDER BY NumOrders DESC;
GO

-- 30. Orders placed by customers without a fax number
-- FaxNumber is not stored in AW2022 → query skipped or adapted.
-- (No direct equivalent in this version)

-- 31. Postal codes where Tofu was shipped
SELECT DISTINCT a.PostalCode
FROM Sales.SalesOrderDetail od
JOIN Sales.SalesOrderHeader o ON od.SalesOrderID = o.SalesOrderID
JOIN Production.Product p ON od.ProductID = p.ProductID
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
WHERE p.Name = 'Tofu';
GO

-- 32. Products shipped to France
SELECT DISTINCT p.Name
FROM Sales.SalesOrderDetail od
JOIN Sales.SalesOrderHeader o ON od.SalesOrderID = o.SalesOrderID
JOIN Production.Product p ON od.ProductID = p.ProductID
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
WHERE sp.CountryRegionCode = 'FR';
GO

-- 33. Products and categories for supplier 'Specialty Biscuits, Ltd.'
SELECT p.Name, pc.Name AS CategoryName
FROM Production.Product p
JOIN Production.ProductSubcategory psc ON p.ProductSubcategoryID = psc.ProductSubcategoryID
JOIN Production.ProductCategory pc ON psc.ProductCategoryID = pc.ProductCategoryID
JOIN Purchasing.ProductVendor pv ON p.ProductID = pv.ProductID
JOIN Purchasing.Vendor v ON pv.BusinessEntityID = v.BusinessEntityID
WHERE v.Name = 'Specialty Biscuits, Ltd.';
GO

-- 34. Products never ordered
SELECT p.ProductID, p.Name
FROM Production.Product p
LEFT JOIN Sales.SalesOrderDetail od ON p.ProductID = od.ProductID
WHERE od.ProductID IS NULL;
GO

-- 35. Products with stock < 10 and units on order = 0
SELECT pi.ProductID, p.Name, pi.Quantity
FROM Production.ProductInventory pi
JOIN Production.Product p ON pi.ProductID = p.ProductID
WHERE pi.Quantity < 10;
GO

-- 36. Top 10 countries by sales
SELECT TOP 10 sp.CountryRegionCode, SUM(soh.TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader soh
JOIN Person.Address a ON soh.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
GROUP BY sp.CountryRegionCode
ORDER BY TotalSales DESC;
GO

-- 37. Orders each employee took for CustomerIDs between A and AO
-- Not applicable, CustomerID is numeric → Skipped.
-- (No equivalent for 'between A and AO')

-- 38. Order date of most expensive order
SELECT TOP 1 OrderDate
FROM Sales.SalesOrderHeader
ORDER BY TotalDue DESC;
GO

-- 39. Product name and total revenue from that product
SELECT p.Name, SUM(od.LineTotal) AS TotalRevenue
FROM Sales.SalesOrderDetail od
JOIN Production.Product p ON od.ProductID = p.ProductID
GROUP BY p.Name
ORDER BY TotalRevenue DESC;
GO

-- 40. SupplierID and number of products offered
SELECT pv.BusinessEntityID AS SupplierID, COUNT(pv.ProductID) AS NumProducts
FROM Purchasing.ProductVendor pv
GROUP BY pv.BusinessEntityID;
GO

-- 41. Top 10 customers based on business
SELECT TOP 10 o.CustomerID, SUM(o.TotalDue) AS TotalBusiness
FROM Sales.SalesOrderHeader o
GROUP BY o.CustomerID
ORDER BY TotalBusiness DESC;
GO

-- 42. Total revenue of the company
SELECT SUM(TotalDue) AS TotalRevenue
FROM Sales.SalesOrderHeader;
GO
